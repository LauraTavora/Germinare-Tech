nome = input('Digite seu nome completo:')
email = input('Digite seu e-mail:')


def validar_email_usuario(email):
     valindando_email = "@" in email.lower() and ".com.br" in email.lower()
     return valindando_email


print (f'E-mail do usuário {nome} é valido? {validar_email_usuario(email)}')

print('-----------------------------------------------------------------------')
def validar_senha(senha):
    maiuscula = False
    minuscula = False
    caracter_especial = False

    caracteres_especiais = ['!', '@', '#', '$', '%']

    if len(senha) < 8:
        return False
    if maiuscula in senha:
        if maiuscula.isupper():
            maiuscula = True
        
        elif minuscula.islower():
            minuscula = True
       
        elif caracteres_especiais in senha:
            caracter_especial = True

    
    if maiuscula and minuscula and caracter_especial:
        return True
    else:
        return False


senha = input("Digite sua senha: ")


if validar_senha(senha):
    print("Senha válida.")
else:
    print("Senha inválida.")