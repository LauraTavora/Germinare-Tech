def inverter_string(texto):
    return texto[::-1]

texto = input('Escreva uma mensagem para invertê-la:')

print(f'A mensagem invertida fica:{inverter_string(texto)}')