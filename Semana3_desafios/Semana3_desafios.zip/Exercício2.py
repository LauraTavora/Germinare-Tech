def inverter_string(texto):
    return texto[::-1]

texto = input('Escreva uma mensagem para invertê-la:')

print(f'A mensagem invertida fica: {inverter_string(texto)}')


def contar_vogais(texto):
    return texto.count('a') + texto.count('A') + texto.count('e') + texto.count('E') + texto.count('i') + texto.count('I') + texto.count('o') + texto.count('O') + texto.count('u') + texto.count('U')


print(f'O número de vogais que existe na mensagem é: {contar_vogais(texto)}')